//
//  ViewController.swift
//  TipCalculator
//
//  Created by Bear Cahill 2022 on 7/6/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var tfBillAmount: UITextField!
    @IBOutlet weak var scTipPercentage: UISegmentedControl!
    
    @IBOutlet weak var lblTip: UILabel!
    @IBOutlet weak var lblTotal: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func doBtnCalc(_ sender: Any) {
        calcTip()
    }
    
    func calcTip() {
        let billAmount = tfBillAmount.text ?? ""
        let billDbl = Double.init(billAmount) ?? 0.0

        let index = scTipPercentage.selectedSegmentIndex
        let tipPercentage = 10 + (5 * index)
        let tipDecimal = Double(tipPercentage) / 100.0

        let tip = billDbl * tipDecimal
        let total = billDbl + tip
        
        let numFmt = NumberFormatter()
        numFmt.numberStyle = .currency
        lblTip.text = numFmt.string(for: tip)
        lblTotal.text = numFmt.string(for: total)
    }
    
}

