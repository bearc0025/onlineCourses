//
//  ViewController.swift
//  Hello World
//
//  Created by Bear Cahill 2022 on 7/5/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var lblHello: UILabel!

    let rect = CGRect(x: 100, y: 260,
                      width: 80, height: 30)
    lazy var tf = UITextField.init(frame: rect)

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        lblHello.text = "Hello iOS"
        
//        var r = lblHello.frame
//        r.origin.y += 60
//        r.size.width = view.frame.size.width * 0.3
      
//        tf.backgroundColor = .gray
        tf.borderStyle = .roundedRect
        view.addSubview(tf)
    }
    
    @IBAction func doBtnAction(_ sender: Any) {
        lblHello.text = tf.text
    }
//        print("tapped")
//        lblHello.text = "Action!"
//        lblHello.backgroundColor = UIColor.yellow
//        lblHello.textColor = UIColor.gray
//        view.backgroundColor = UIColor.darkGray
//    }
    
}

