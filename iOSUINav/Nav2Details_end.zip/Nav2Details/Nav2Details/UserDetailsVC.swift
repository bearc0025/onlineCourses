//
//  UserDetailsVC.swift
//  Nav2Details
//
//  Created by Bear Cahill 2022 on 7/15/22.
//

import UIKit

class UserDetailsVC: UIViewController {

    var user : User?
    @IBOutlet weak var lblUsername: UILabel!
    @IBOutlet weak var lblScore: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        lblUsername.text = user?.name ?? "(No Username)"
        lblScore.text = "\(user?.score ?? 0)"
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
