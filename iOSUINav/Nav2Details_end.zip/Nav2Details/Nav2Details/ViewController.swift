//
//  ViewController.swift
//  Nav2Details
//
//  Created by Bear Cahill 2022 on 7/15/22.
//

import UIKit

struct User {
    var name = ""
    var score = 0
}

class ViewController: UIViewController {

    @IBOutlet weak var tvItems: UITableView!
    var items = [User]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        for x in 0..<30 {
            items.append(User(name: userName(len: 5 + (x % 3)), score: Int(arc4random()) % 100))
        }
    }
    
    func userName(len : Int) -> String {
        let consonants = "bcdfghjklmnpqrstvwxyz"
        let vowels = "aeiou"
        return String((0..<len).map{
            $0 % 2 == 0 ? consonants.randomElement()! : vowels.randomElement()!
        })
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "segDetails" {
            guard let vc = segue.destination as? UserDetailsVC else { return }
            guard let index = tvItems.indexPathForSelectedRow?.row else { return }
            vc.user = items[index]
        }
    }

}

extension ViewController : UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        items.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cellData", for: indexPath)
        
        var cc = cell.defaultContentConfiguration()
        let user = items[indexPath.row]
        cc.text = user.name
        cc.secondaryText = "Score: \(user.score)"
        cell.contentConfiguration = cc
        
        return cell
    }
    
    
}
