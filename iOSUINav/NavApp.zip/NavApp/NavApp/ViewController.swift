//
//  ViewController.swift
//  NavApp
//
//  Created by Bear Cahill 2022 on 7/13/22.
//

import UIKit

class ViewController: UIViewController {

    let userLoggedIn = true
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
//        performSegue(withIdentifier: "segNav1", sender: self)
        
        print (self.navigationController?.viewControllers.count)
        
        let bbi1 = UIBarButtonItem(systemItem: .action)
        let bbi2 = UIBarButtonItem(systemItem: .camera)
        toolbarItems = [bbi1, bbi2]
        
        self.tabBarController?.selectedIndex = 0
    }

    override func shouldPerformSegue(withIdentifier identifier: String,
                                     sender: Any?) -> Bool {
        if identifier == "segNav1" {
            return userLoggedIn
        }
        return true
    }
    
    override func prepare(for segue: UIStoryboardSegue,
                          sender: Any?) {
        if segue.identifier == "segNav1" {
            guard let vc = segue.destination as? SecondViewController
                else { return }
            vc.textForSVC = "\(Date().formatted(date: .omitted, time: .standard))"
        }
    }

}

