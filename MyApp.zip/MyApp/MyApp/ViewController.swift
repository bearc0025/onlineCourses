//
//  ViewController.swift
//  MyApp
//
//  Created by Bear Cahill 2022 on 7/26/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    func testMe(val : Int) -> Int {
        val * 2
    }

}

