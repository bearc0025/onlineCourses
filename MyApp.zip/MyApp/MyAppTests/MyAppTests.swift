//
//  MyAppTests.swift
//  MyAppTests
//
//  Created by Bear Cahill 2022 on 7/26/22.
//

import XCTest
@testable import MyApp

class UnitTesting: XCTestCase {
//    override func setUp(completion: @escaping (Error?) -> Void) {
//        print ("setUp(completion: @escaping (Error?) -> Void)")
//        completion(nil)
//    }
    
    var date : Date?
    override func setUpWithError() throws {
        print ("setUpWithError")
        date = Date()
        
    }
    
//    override func setUp() {
//        print ("setUp")
//    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }
    
    func testThis() {
        
    }

    func testExample() throws {
        let vc = ViewController()
        let result = vc.testMe(val: 5)
        XCTAssert(result == 10, "Value should be 10 but was \(result)")
        XCTAssertEqual(1.0, 1.05, accuracy: 0.1)
    }

    func testPerformanceExample() throws {
        // This is an example of a performance test case.
        var count = 0
        measure {
            // Put the code you want to measure the time of here.
            if count < 3 {
                for _ in 0..<1000 {
                    let url = URL(fileURLWithPath: NSTemporaryDirectory() + "file.txt")
                    if let d = "test".data(using: .utf8) {
                        try? d.write(to: url)
                    }
                }
            }
            count += 1
        }
    }

}
