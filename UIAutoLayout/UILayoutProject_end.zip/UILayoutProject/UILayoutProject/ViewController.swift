//
//  ViewController.swift
//  UILayoutProject
//
//  Created by Bear Cahill 2022 on 7/13/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

