//
//  ViewController.swift
//  Visual
//
//  Created by Bear Cahill 2022 on 7/11/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var ivNew: UIImageView!
    @IBOutlet weak var ivOriginal: UIImageView!
    
    @IBOutlet weak var lblOne: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        var r = lblOne.frame
        r.origin.y += 10
        lblOne.frame = r
        
        ivNew.translatesAutoresizingMaskIntoConstraints = false
        
        let cY = ivNew.bottomAnchor.constraint(equalTo: ivOriginal.topAnchor,
                                               constant: -30)
        cY.isActive = true
        let cAspectRatio = ivNew.heightAnchor.constraint(equalTo: ivNew.widthAnchor,
                                                         multiplier: 8.0/15.0)
        
        let cWidth = ivNew.widthAnchor.constraint(equalTo: view.widthAnchor,
                                          multiplier: 0.57971)
        
        let cCenterX = NSLayoutConstraint(item: ivNew as Any,
                                          attribute: .centerX,
                                          relatedBy: .equal,
                                          toItem: view,
                                          attribute: .centerX,
                                          multiplier: 1.0,
                                          constant: 0)

        NSLayoutConstraint.activate([cAspectRatio, cCenterX, cWidth])
    }


}

