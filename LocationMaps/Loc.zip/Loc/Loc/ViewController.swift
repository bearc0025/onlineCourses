//
//  ViewController.swift
//  Loc
//
//  Created by Bear Cahill 2022 on 8/17/22.
//

import UIKit
import CoreLocation

class ViewController: UIViewController {

    let locMgr = CLLocationManager()

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        guard CLLocationManager.locationServicesEnabled() else {

            let ac = UIAlertController(title: "Location Services",
                message: "Please enable location services in Settings > Privacy.",
                preferredStyle:.alert)

            ac.addAction(UIAlertAction(title: "OK", style: .default))

            self.present(ac, animated: true)

            return
        }

        requestLocAuth()
    }
    
    func requestLocAuth() {
        locMgr.delegate = self
        locMgr.desiredAccuracy = 100
        locMgr.distanceFilter = 1000
        
        if locMgr.authorizationStatus == .authorizedWhenInUse {
            locMgr.startUpdatingLocation()
        } else {
            locMgr.requestWhenInUseAuthorization()
        }
    }
}

extension ViewController : CLLocationManagerDelegate {
    
    func locationManagerDidChangeAuthorization(_ manager:
                                        CLLocationManager) {
        if locMgr.authorizationStatus == .authorizedWhenInUse {
            locMgr.startUpdatingLocation()
        }
    }
    
    func locationManager(_ manager: CLLocationManager,
         didUpdateLocations locations: [CLLocation]) {
        if let loc = locations.last {
            print (loc.coordinate)
        }
    }
}


