//
//  ViewController.swift
//  MapSearch
//
//  Created by Bear Cahill 2022 on 8/18/22.
//

import UIKit
import MapKit

class ViewController: UIViewController {

    @IBOutlet weak var mapView: MKMapView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    func search(text : String) {
    }
}

extension ViewController : UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        guard let text = textField.text else { return false }
        search(text: text)
        return false
    }
}

extension ViewController : CLLocationManagerDelegate {

}
