//
//  ViewController.swift
//  MapSearch
//
//  Created by Bear Cahill 2022 on 8/18/22.
//

import UIKit
import CoreLocation
import MapKit

class ViewController: UIViewController {

    @IBOutlet weak var mapView: MKMapView!
    
    let locMgr = CLLocationManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        locMgr.delegate = self
        locMgr.requestWhenInUseAuthorization()
    }


    func search(text : String) {
        CLGeocoder().geocodeAddressString(text) { pms, error in
            guard error == nil, let pms = pms,
                  pms.count > 0, let pm = pms.first,
                  let loc = pm.location else { return }
            let ann = MKPointAnnotation()
            ann.coordinate = loc.coordinate
            ann.title = text
            self.mapView.addAnnotation(ann)
            self.mapView.showAnnotations([ann], animated: true)
        }
    }
}

extension ViewController : UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        guard let text = textField.text else { return false }
        search(text: text)
        return false
    }
}

extension ViewController : CLLocationManagerDelegate {

}
