//
//  ViewController.swift
//  Loc
//
//  Created by Bear Cahill 2022 on 8/17/22.
//

import UIKit
import CoreLocation
import Contacts

import MapKit

class ViewController: UIViewController {

    var totalDistance = 0.0

    let locMgr = CLLocationManager()
    let mapView = MKMapView()
    
    var prevLocation : CLLocation?

    override func viewDidLoad() {
        super.viewDidLoad()
        mapView.frame = view.frame.insetBy(dx: 40,
                                           dy: 40)
        view.addSubview(mapView)
        
        mapView.showsUserLocation = true
        mapView.setUserTrackingMode(.follow, animated: false)
        
        mapView.delegate = self
        
        let lpg = UILongPressGestureRecognizer(target: self, action: #selector(handleLongPress))
        mapView.addGestureRecognizer(lpg)
    }
    
    @objc func handleLongPress(_ sender : UILongPressGestureRecognizer) {
        // 1. check the state to avoid multiple passes
        guard sender.state != .ended else { return }
        // 2. Get the touch point
        let point = sender.location(in: mapView)
        // 3. Convert point to coordinate and make location
        let coord = mapView.convert(point,
                                    toCoordinateFrom: mapView)
        let loc = CLLocation(latitude: coord.latitude,
                             longitude: coord.longitude)
        // 4. Reverse geocode location
        CLGeocoder().reverseGeocodeLocation(loc) { pms, error in
            guard error == nil, let pms = pms, let pm = pms.first
                else { return }
            guard let postalAddr = pm.postalAddress
                else { return }
            // 5. Format the address from the placemark
            let addr = CNPostalAddressFormatter.string(from: postalAddr,
                                                style: .mailingAddress)
            print (addr)
        }
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        guard CLLocationManager.locationServicesEnabled() else {

            let ac = UIAlertController(title: "Location Services",
                message: "Please enable location services in Settings > Privacy.",
                preferredStyle:.alert)

            ac.addAction(UIAlertAction(title: "OK", style: .default))

            self.present(ac, animated: true)

            return
        }

        requestLocAuth()
    }
    
    func requestLocAuth() {
        locMgr.delegate = self
        locMgr.desiredAccuracy = 100
        locMgr.distanceFilter = 1000
        
        if locMgr.authorizationStatus == .authorizedWhenInUse {
            locMgr.startUpdatingLocation()
        } else {
            locMgr.requestWhenInUseAuthorization()
        }
    }
}

extension ViewController : CLLocationManagerDelegate {
    
    func locationManagerDidChangeAuthorization(_ manager:
                                        CLLocationManager) {
        if locMgr.authorizationStatus == .authorizedWhenInUse {
            locMgr.startUpdatingLocation()
        }
    }
    
    func locationManager(_ manager: CLLocationManager,
         didUpdateLocations locations: [CLLocation]) {
        if let loc = locations.last {
            print (loc.coordinate)
        }
    }
}


extension ViewController : MKMapViewDelegate {
    
    func mapView(_ mapView: MKMapView,
        didUpdate userLocation: MKUserLocation) {
        
        // 1. Do we have a previous location?
        if let prevLoc = prevLocation {
            // 2. Calculate the distance
            let dist = userLocation.location?
                    .distance(from: prevLoc) ?? 0
            // 3. If it's at least 100 meters
            guard dist >= 100 else { return }
        }
        
        // 4. Create annotation and store location
        createAnnotation(location: userLocation.location)
    }
    
    func createAnnotation(location : CLLocation?) {
        if let prevLoc = prevLocation {
            totalDistance += location?.distance(from: prevLoc) ?? 0
        }
        prevLocation = location

        guard let loc = location else { return }
        CLGeocoder().reverseGeocodeLocation(loc) { placemarks, error in
            guard error == nil, let pms = placemarks, pms.count > 0,
            let pm = pms.first else { return }
            print (pm.name ?? "no name")
            self.finishAnnotation(coord: loc.coordinate,
                                  title: pm.name ?? "no name")

            CLGeocoder().geocodeAddressString("200 North Locust, Denton, TX 76201")
            { pms2, error in
                guard error == nil, let pms = pms2, pms.count > 0,
                      let pm2 = pms.first,
                      let pm2Loc = pm2.location else { return }
                print ("\(pm2Loc.coordinate.latitude),\(pm2Loc.coordinate.longitude)")
            }
        }
    }
    
    func finishAnnotation(coord : CLLocationCoordinate2D,
                          title : String) {
        let ann = MKPointAnnotation()
        ann.coordinate = coord
        ann.title = title
        ann.subtitle = "\(Int(totalDistance))m"
        mapView.addAnnotation(ann)
        mapView.userTrackingMode = .none
        mapView.showAnnotations(mapView.annotations,
                                animated: true)
    }
}
