//
//  ShoppingMgr.swift
//  ShoppingList
//
//  Created by Bear Cahill 2022 on 9/13/22.
//

import Amplify

class ShoppingMgr {
    static var shared = ShoppingMgr()
    private init() {    }

    func createShoppingList() {
        let item = ShoppingList(
                name: "List 1",
                location: "Bear's Store",
                url:  "https://www.example.com",
                Items: [])
        Amplify.DataStore.save(item) { result in
            switch(result) {
            case .success(let savedItem):
                print("Saved item: \(savedItem.id)")
            case .failure(let error):
                print("Could not save item to DataStore: \(error)")
            }
        }
    }
}
