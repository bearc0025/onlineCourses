//
//  ContentView.swift
//  ShoppingList
//
//  Created by Bear Cahill 2022 on 9/12/22.
//

import SwiftUI

struct ContentView: View {
    
    var userMgr = UserMgr.shared
    var shoppingMgr = ShoppingMgr.shared
    
    var body: some View {
        Text("Hello, world!")
            .padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
