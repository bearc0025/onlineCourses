//
//  ShoppingListApp.swift
//  ShoppingList
//
//  Created by Bear Cahill 2022 on 9/12/22.
//

import SwiftUI

@main
struct ShoppingListApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
