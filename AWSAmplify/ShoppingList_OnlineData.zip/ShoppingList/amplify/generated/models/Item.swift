// swiftlint:disable all
import Amplify
import Foundation

public struct Item: Model {
  public let id: String
  public var name: String
  public var size: String?
  public var quantity: Int?
  public var shoppinglistID: String
  public var createdAt: Temporal.DateTime?
  public var updatedAt: Temporal.DateTime?
  
  public init(id: String = UUID().uuidString,
      name: String,
      size: String? = nil,
      quantity: Int? = nil,
      shoppinglistID: String) {
    self.init(id: id,
      name: name,
      size: size,
      quantity: quantity,
      shoppinglistID: shoppinglistID,
      createdAt: nil,
      updatedAt: nil)
  }
  internal init(id: String = UUID().uuidString,
      name: String,
      size: String? = nil,
      quantity: Int? = nil,
      shoppinglistID: String,
      createdAt: Temporal.DateTime? = nil,
      updatedAt: Temporal.DateTime? = nil) {
      self.id = id
      self.name = name
      self.size = size
      self.quantity = quantity
      self.shoppinglistID = shoppinglistID
      self.createdAt = createdAt
      self.updatedAt = updatedAt
  }
}