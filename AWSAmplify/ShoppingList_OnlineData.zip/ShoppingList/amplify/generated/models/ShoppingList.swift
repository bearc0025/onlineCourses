// swiftlint:disable all
import Amplify
import Foundation

public struct ShoppingList: Model {
  public let id: String
  public var name: String
  public var location: String?
  public var url: String?
  public var Items: List<Item>?
  public var createdAt: Temporal.DateTime?
  public var updatedAt: Temporal.DateTime?
  
  public init(id: String = UUID().uuidString,
      name: String,
      location: String? = nil,
      url: String? = nil,
      Items: List<Item>? = []) {
    self.init(id: id,
      name: name,
      location: location,
      url: url,
      Items: Items,
      createdAt: nil,
      updatedAt: nil)
  }
  internal init(id: String = UUID().uuidString,
      name: String,
      location: String? = nil,
      url: String? = nil,
      Items: List<Item>? = [],
      createdAt: Temporal.DateTime? = nil,
      updatedAt: Temporal.DateTime? = nil) {
      self.id = id
      self.name = name
      self.location = location
      self.url = url
      self.Items = Items
      self.createdAt = createdAt
      self.updatedAt = updatedAt
  }
}