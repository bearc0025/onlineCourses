// swiftlint:disable all
import Amplify
import Foundation

extension ShoppingList {
  // MARK: - CodingKeys 
   public enum CodingKeys: String, ModelKey {
    case id
    case name
    case location
    case url
    case Items
    case createdAt
    case updatedAt
  }
  
  public static let keys = CodingKeys.self
  //  MARK: - ModelSchema 
  
  public static let schema = defineSchema { model in
    let shoppingList = ShoppingList.keys
    
    model.authRules = [
      rule(allow: .public, operations: [.create, .update, .delete, .read])
    ]
    
    model.pluralName = "ShoppingLists"
    
    model.fields(
      .id(),
      .field(shoppingList.name, is: .required, ofType: .string),
      .field(shoppingList.location, is: .optional, ofType: .string),
      .field(shoppingList.url, is: .optional, ofType: .string),
      .hasMany(shoppingList.Items, is: .optional, ofType: Item.self, associatedWith: Item.keys.shoppinglistID),
      .field(shoppingList.createdAt, is: .optional, isReadOnly: true, ofType: .dateTime),
      .field(shoppingList.updatedAt, is: .optional, isReadOnly: true, ofType: .dateTime)
    )
    }
}