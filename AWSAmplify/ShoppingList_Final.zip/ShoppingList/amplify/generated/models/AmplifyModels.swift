// swiftlint:disable all
import Amplify
import Foundation

// Contains the set of classes that conforms to the `Model` protocol. 

final public class AmplifyModels: AmplifyModelRegistration {
  public let version: String = "7b5b6345618d7f088b332b177daeddff"
  
  public func registerModels(registry: ModelRegistry.Type) {
    ModelRegistry.register(modelType: Item.self)
    ModelRegistry.register(modelType: ShoppingList.self)
  }
}