// swiftlint:disable all
import Amplify
import Foundation

public struct ShoppingList: Model {
  public let id: String
  public var userId: String
  public var location: String?
  public var url: String?
  public var Items: List<Item>?
  public var name: String?
  public var createdAt: Temporal.DateTime?
  public var updatedAt: Temporal.DateTime?
  
  public init(id: String = UUID().uuidString,
      userId: String,
      location: String? = nil,
      url: String? = nil,
      Items: List<Item>? = [],
      name: String? = nil) {
    self.init(id: id,
      userId: userId,
      location: location,
      url: url,
      Items: Items,
      name: name,
      createdAt: nil,
      updatedAt: nil)
  }
  internal init(id: String = UUID().uuidString,
      userId: String,
      location: String? = nil,
      url: String? = nil,
      Items: List<Item>? = [],
      name: String? = nil,
      createdAt: Temporal.DateTime? = nil,
      updatedAt: Temporal.DateTime? = nil) {
      self.id = id
      self.userId = userId
      self.location = location
      self.url = url
      self.Items = Items
      self.name = name
      self.createdAt = createdAt
      self.updatedAt = updatedAt
  }
}