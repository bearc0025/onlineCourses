//
//  UserMgr.swift
//  ShoppingList
//
//  Created by Bear Cahill 2022 on 9/12/22.
//

import Amplify
import AWSCognitoAuthPlugin
import Combine
import AWSAPIPlugin
import AWSDataStorePlugin

import Foundation
import UIKit

class UserMgr {
    static var shared = UserMgr()
    var userCancellables = Set<AnyCancellable>()
    
    @objc func applicationWillTerminate(notification: Notification) {
        Amplify.DataStore.clear { result in
            print ("cleared cache")
            print (result)
        }
    }

    private init() {

        NotificationCenter.default.addObserver(self,
              selector: #selector(applicationWillTerminate(notification:)),
              name: UIApplication.willTerminateNotification,
              object: nil)
        
        do {
            try Amplify.add(plugin:
                    AWSCognitoAuthPlugin())
            
            try Amplify.add(plugin:
                AWSAPIPlugin(modelRegistration: AmplifyModels()))
            try Amplify.add(plugin:
                AWSDataStorePlugin(modelRegistration: AmplifyModels()))
            
            try Amplify.configure()
            
            if let userId = Amplify.Auth.getCurrentUser()?.userId {
//                let sList = ShoppingList(userId: userId,
//                                         location: "My Store",
//                                         url: "https://www.example.com",
//                                         name: "My List")
//                ShoppingMgr.shared.createShoppingList(shoppingList: sList)
                
                ShoppingMgr.shared.fetchShoppingLists(for: userId,
                                                      completion: { lists in
                    if var list = lists?.first {
//                        list.name = "Updated Name"
//                        ShoppingMgr.shared.updateShoppingList(shoppingList: list)

//                        ShoppingMgr.shared.createListItem(item: Item(name: "Coffee", size: "100oz", quantity: 1000, shoppinglistID: list.id))
                        
//                        ShoppingMgr.shared.fetchListItems(shoppingListID: list.id,
//                                                          completion: { items in
//                            items?.forEach {
//                                print ($0)
//                                ShoppingMgr.shared.deleteListItem(item: $0)
//                            }
//                        })
                        ShoppingMgr.shared.deleteShoppingList(shoppingList: list)
                    }
                })
                
                
            }
            
            
//            signUp(username: "bear@brainwashinc.com",
//                   password: "User0001!",
//                   email: "bear@brainwashinc.com")
//            .store(in: &userCancellables)
            
//            confirmSignUp(for: "bear@brainwashinc.com", with: "363736")
//                .store(in: &userCancellables)
            
//            signIn(username: "bear@brainwashinc.com", password: "User0001!")
//                .store(in: &userCancellables)
            
//            Amplify.Auth.getCurrentUser()?.userId
            
            
        } catch {
            print (error)
        }
    }
    
    func signUp(username: String, password: String, email: String) -> AnyCancellable {
        let userAttributes = [AuthUserAttribute(.email, value: email)]
        let options = AuthSignUpRequest.Options(userAttributes: userAttributes)
        let sink = Amplify.Auth.signUp(username: username, password: password, options: options)
            .resultPublisher
            .sink {
                if case let .failure(authError) = $0 {
                    print("An error occurred while registering a user \(authError)")
                }
            }
            receiveValue: { signUpResult in
                if case let .confirmUser(deliveryDetails, _) = signUpResult.nextStep {
                    print("Delivery details \(String(describing: deliveryDetails))")
                } else {
                    print("SignUp Complete")
                }

            }
        return sink
    }
    
    func confirmSignUp(for username: String,
                       with confirmationCode: String) -> AnyCancellable {
        Amplify.Auth.confirmSignUp(for: username,
                       confirmationCode: confirmationCode)
            .resultPublisher
            .sink {
                if case let .failure(authError) = $0 {
                    print("An error occurred while confirming sign up \(authError)")
                }
            }
            receiveValue: { _ in
                print("Confirm signUp succeeded")
            }
    }
    
    func signIn(username: String, password: String) -> AnyCancellable {
        Amplify.Auth.signIn(username: username, password: password)
            .resultPublisher
            .sink {
                if case let .failure(authError) = $0 {
                    print("Sign in failed \(authError)")
                }
            }
            receiveValue: { _ in
                print("Sign in succeeded")
            }
    }
}


