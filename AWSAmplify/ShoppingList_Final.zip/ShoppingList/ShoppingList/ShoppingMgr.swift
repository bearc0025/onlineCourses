//
//  ShoppingMgr.swift
//  ShoppingList
//
//  Created by Bear Cahill 2022 on 9/13/22.
//

import Amplify

class ShoppingMgr {
    static var shared = ShoppingMgr()
    private init() {    }

    func createShoppingList(shoppingList : ShoppingList) {
        Amplify.DataStore.save(shoppingList) { result in
            switch(result) {
            case .success(let savedItem):
                print("Saved item: \(savedItem.id)")
            case .failure(let error):
                print("Could not save item to DataStore: \(error)")
            }
        }
    }
    
    func fetchShoppingLists(for userId: String,
                            completion : @escaping ([ShoppingList]?)->Void) { 
        let sList = ShoppingList.keys
        let predicate = sList.userId == userId
        Amplify.DataStore.query(ShoppingList.self, where: predicate) { result in
            switch(result) {
            case .success(let list):
                print("Fetched item(s): \(list)")
                completion(list)
            case .failure(let error):
                print("Could not fetch from DataStore: \(error)")
            }
        }
    }
    
    func updateShoppingList(shoppingList : ShoppingList) {
        Amplify.DataStore.save(shoppingList) { result in
            switch(result) {
            case .success(let savedItem):
                print("Saved item: \(savedItem.id)")
            case .failure(let error):
                print("Could not save item to DataStore: \(error)")
            }
        }
    }
    
    func deleteShoppingList(shoppingList: ShoppingList) {
        Amplify.DataStore.delete(shoppingList) { result in
            switch(result) {
            case .success:
                print("Deleted item: \(shoppingList.id)")
            case .failure(let error):
                print("Could not update data in Datastore: \(error)")
            }
        }
    }
    
    func createListItem(item : Item) {
        Amplify.DataStore.save(item) { result in
            switch(result) {
            case .success(let savedItem):
                print("Saved item: \(savedItem.id)")
            case .failure(let error):
                print("Could not save item to DataStore: \(error)")
            }
        }
    }
    
    func fetchListItems(shoppingListID : String,
                        completion : @escaping ([Item]?)->Void) {
        let itemKeys = Item.keys
        let predicate = itemKeys.shoppinglistID == shoppingListID
        Amplify.DataStore.query(Item.self, where: predicate) { result in
            switch(result) {
            case .success(let items):
                print("Fetched item(s): \(items)")
                completion(items)
            case .failure(let error):
                print("Could not fetch from DataStore: \(error)")
            }
        }
    }
    
    func updateListItem(item : Item) {
        Amplify.DataStore.save(item) { result in
            switch(result) {
            case .success(let savedItem):
                print("Saved item: \(savedItem.id)")
            case .failure(let error):
                print("Could not save item to DataStore: \(error)")
            }
        }
    }
    
    func deleteListItem(item: Item) { 
        Amplify.DataStore.delete(item) { result in
            switch(result) {
            case .success:
                print("Deleted item: \(item.id)")
            case .failure(let error):
                print("Could not update data in Datastore: \(error)")
            }
        }
    }
}
