//
//  UserMgr.swift
//  ShoppingList
//
//  Created by Bear Cahill 2022 on 9/12/22.
//

import Amplify
import AWSCognitoAuthPlugin
import Combine

class UserMgr {
    static var shared = UserMgr()
    
    var userCancellables = Set<AnyCancellable>()
    
    private init() {
        do {
            try Amplify.add(plugin:
                    AWSCognitoAuthPlugin())
            try Amplify.configure()
            
//            signUp(username: "bear@brainwashinc.com",
//                   password: "User0001!",
//                   email: "bear@brainwashinc.com")
//            .store(in: &userCancellables)
            
//            confirmSignUp(for: "bear@brainwashinc.com", with: "363736")
//                .store(in: &userCancellables)
            
        } catch {
            print (error)
        }
    }
    
    func signUp(username: String, password: String, email: String) -> AnyCancellable {
        let userAttributes = [AuthUserAttribute(.email, value: email)]
        let options = AuthSignUpRequest.Options(userAttributes: userAttributes)
        let sink = Amplify.Auth.signUp(username: username, password: password, options: options)
            .resultPublisher
            .sink {
                if case let .failure(authError) = $0 {
                    print("An error occurred while registering a user \(authError)")
                }
            }
            receiveValue: { signUpResult in
                if case let .confirmUser(deliveryDetails, _) = signUpResult.nextStep {
                    print("Delivery details \(String(describing: deliveryDetails))")
                } else {
                    print("SignUp Complete")
                }

            }
        return sink
    }
    
    func confirmSignUp(for username: String,
                       with confirmationCode: String) -> AnyCancellable {
        Amplify.Auth.confirmSignUp(for: username,
                       confirmationCode: confirmationCode)
            .resultPublisher
            .sink {
                if case let .failure(authError) = $0 {
                    print("An error occurred while confirming sign up \(authError)")
                }
            }
            receiveValue: { _ in
                print("Confirm signUp succeeded")
            }
    }
}


