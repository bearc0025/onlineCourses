//
//  ViewController.swift
//  TableViewProtocols
//
//  Created by Bear Cahill 2022 on 7/28/22.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var names = ["Bear", "Schmeb", "Taco", "Jed", "Mo", "Maco"]
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        names.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let name = names[indexPath.row]
           
        let cell = tableView.dequeueReusableCell(withIdentifier: "cellID", for: indexPath)
        
        var contentConfig = cell.defaultContentConfiguration()
        contentConfig.text = name
        contentConfig.secondaryText = "\(indexPath.row)"
        cell.contentConfiguration = contentConfig
        return cell
    }
    
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        
        let action = UIContextualAction(style: .destructive,
                    title: "Delete") { action, view, handlerDone in
            
            self.names.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .automatic)
            handlerDone(true)
            
        }
        
        return UISwipeActionsConfiguration(actions: [action])
    }

    
    
    
    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

