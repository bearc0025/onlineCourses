//
//  ViewController.swift
//  Ext
//
//  Created by Bear Cahill 2022 on 7/28/22.
//

import UIKit

extension UIView {
    func cover(secs : Int) {
        DispatchQueue.main.async {
            let v = UIView(frame: self.bounds)
            v.backgroundColor = .purple
            self.addSubview(v)
            Timer.scheduledTimer(withTimeInterval: 1.0,
                                 repeats: false) { _ in
                v.removeFromSuperview()
            }
        }
    }
}

class ViewController: UIViewController {

    @IBOutlet weak var ivImage: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        print (Date().dateString)
        
        let saveables : [Saveable] = ["test", 1, "this", 55]
        saveables.forEach { saveable in
            let url = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask).first!.appendingPathComponent(UUID().uuidString)
            saveable.save(to: url)
        }
        
//        displaySpinner()
//        Timer.scheduledTimer(withTimeInterval: 5.0, repeats: false) { _ in
//            self.removeSpinner()
//        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if let url = URL(string: "https://source.unsplash.com/random") {
            self.ivImage.loadImage(url: url)
            self.ivImage.cover(secs: 2)
        }
    }
}

extension ViewController : UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return false
    }
}

