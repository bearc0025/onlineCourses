//
//  Extensions.swift
//  Ext
//
//  Created by Bear Cahill 2022 on 7/28/22.
//

import Foundation
import UIKit

extension String {
    func reverseUpper() -> String {
        let result = self.reversed()
        let returnMe = String(result)
        return returnMe.uppercased()
    }
}

extension Date {
    var dateString : String {
        let df = DateFormatter()
        df.dateStyle = .medium
        df.timeStyle = .none
        return df.string(from: self)
    }
}

class Employee : Equatable {
    var name = ""
    var id = 0

    static func == (lhs: Employee,
                    rhs: Employee) -> Bool {
        lhs.id == rhs.id
    }
}

let SPINNERTAG = 999
extension UIView {
    func displaySpinner() {
        let overlayView = UIView(frame: self.bounds)
        overlayView.tag = SPINNERTAG
        overlayView.backgroundColor = UIColor(red: 0.5,
                                              green: 0.5,
                                              blue: 0.5,
                                              alpha: 0.5)
        let actInd = UIActivityIndicatorView(style: .large)
        actInd.center = overlayView.center
        actInd.startAnimating()
        overlayView.addSubview(actInd)
        self.addSubview(overlayView)
    }
    
    func removeSpinner() {
        if let overlayView = self.viewWithTag(SPINNERTAG) {
            overlayView.removeFromSuperview()
        }
    }
}


extension UIViewController {
    func displaySpinner() {
        view.displaySpinner()
    }
    func removeSpinner() {
        view.removeSpinner()
    }
}

extension URL {
    func fetchData(handler : @escaping (Data?)->Void) {
        URLSession.shared.dataTask(with: self) { data, resp, error in
            handler(data)
        }.resume()
    }

    func fetchImage(handler : @escaping (UIImage?)->Void) {
        fetchData { data in
            guard let data = data else { handler(nil); return }
            handler(UIImage(data: data))
        }
    }
}

extension UIImage {
    static func loadImage(url : URL,
                          handler : @escaping (UIImage?)->Void) {
        url.fetchImage { img in
            handler(img)
        }
    }
}


extension UIImageView {
    func loadImage(url : URL) {
        self.displaySpinner()
        UIImage.loadImage(url: url) { image in
            DispatchQueue.main.async {
                self.image = image
                self.removeSpinner()
            }
        }
    }
}

