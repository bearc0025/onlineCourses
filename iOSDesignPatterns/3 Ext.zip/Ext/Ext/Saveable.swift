//
//  Saveable.swift
//  Ext
//
//  Created by Bear Cahill 2022 on 7/28/22.
//

import Foundation
import UIKit

protocol Saveable {
    func save(to fileURL : URL)
    init?(from fileURL : URL)
}

extension String : Saveable {
    func save(to fileURL: URL) {
        guard let data = self.data(using: .utf8)
            else { return }
        try? data.write(to: fileURL)
    }
    init?(from fileURL: URL) {
        guard let data = try? Data(contentsOf: fileURL)
            else { return nil }
        self.init(data: data, encoding: .utf8)
    }
}

extension Int : Saveable {
    func save(to fileURL: URL) {
        guard let data = "\(self)".data(using: .utf8)
            else { return }
        try? data.write(to: fileURL)
    }
    
    init?(from fileURL: URL) {
        guard let data = try? Data(contentsOf: fileURL)
            else { return nil }
        guard let str = String(data: data, encoding: .utf8)
            else { return nil }
        self.init(str)
    }
}
