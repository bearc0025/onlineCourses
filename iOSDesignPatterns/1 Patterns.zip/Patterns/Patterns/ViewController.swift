//
//  ViewController.swift
//  Patterns
//
//  Created by Bear Cahill 2022 on 7/28/22.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var tf1: UITextField!
    @IBOutlet weak var tf2: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        tf1.delegate = self
        tf2.delegate = self
    }

    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        if textField == tf1 {
            return true
        } else if let text = tf1.text, text.count > 0 {
            return true
        }
        return false
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField == tf1 {
            tf2.becomeFirstResponder()
        } else {
            tf2.resignFirstResponder()
        }
        return false
    }
}

