//
//  ViewController.swift
//  SimpleGame
//
//  Created by Bear Cahill 2022 on 8/17/22.
//

import UIKit

class ViewController: UIViewController {

    var viewCount = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { timer in
            let v = self.addRandomView()
            self.viewCount += 1
            if self.viewCount > 9 {
                timer.invalidate()
            }
            Timer.scheduledTimer(withTimeInterval: 5.0, repeats: false) { _ in
                v.removeFromSuperview()
            }
        }
    }

    var randHW : CGFloat {
        CGFloat.random(in: 50..<100)
    }
    
    var randSize : CGSize {
        CGSize(width: randHW, height: randHW)
    }
    
    var randX : CGFloat {
        CGFloat.random(in: 0..<view.frame.size.width)
    }
    
    var randY : CGFloat {
        CGFloat.random(in: 0..<view.frame.size.height)
    }
    
    var randPoint : CGPoint {
        CGPoint(x: randX, y: randY)
    }
    
    var randNum : CGFloat {
        CGFloat.random(in: 0..<255) / 255.0
    }
    
    var randColor : UIColor {
        UIColor(red: randNum, green: randNum, blue: randNum, alpha: 1.0)
    }
    
    var randView : UIView {
        var rect = CGRect(origin: randPoint, size: randSize)
        while view.frame.insetBy(dx: 30, dy: 30).contains(rect) == false {
            rect = CGRect(origin: randPoint, size: randSize)
        }
        let v = UIView(frame: rect)
        v.configAppearance()
        v.backgroundColor = randColor
        return v
    }

    func addRandomView() -> UIView {
        let v = randView
        // animate adding the view
        view.addSubview(v)
        return v
    }
    
    func checkForHit(point : CGPoint) -> UIView? {
        view.subviews.first { $0.frame.contains(point) }
    }
    
    func processTouch(touch : UITouch) {
        guard let v = checkForHit(point: touch.location(in: view))
        else {
            return
        }
        // animate removing the view
        v.removeFromSuperview()
        viewCount -= 1
    }
    
    // add code to handle the touches and call processTouch (above)
    
}

extension UIView {
    func configAppearance() {
        let smallerSide = min(frame.size.width, frame.size.height)
        self.layer.cornerRadius = smallerSide / 2.0
        self.layer.borderWidth = 1
        self.layer.borderColor = UIColor.gray.cgColor
        self.layer.shadowOffset = CGSize(width: 5, height: 5)
        self.layer.shadowColor = UIColor.gray.cgColor
        self.layer.shadowOpacity = 0.5
    }
}
