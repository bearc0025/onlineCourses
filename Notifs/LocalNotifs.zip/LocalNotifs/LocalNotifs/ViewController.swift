//
//  ViewController.swift
//  LocalNotifs
//
//  Created by Bear Cahill 2022 on 8/24/22.
//

import UIKit
import CoreLocation

class ViewController: UIViewController {

    let locMgr = CLLocationManager()
    
    var startLocation : CLLocation? {
        didSet {
            if let startLocation = startLocation {
                self.addLocNotification(loc: startLocation)
            }
        }
    }
    
    let CategoryName = "ActionCat"
    
    enum NotifActions : String {
        case edit = "Edit"
        case repeet = "Repeat" // repeat is keyword
        case end = "End"
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        UIApplication.shared.applicationIconBadgeNumber = 0

        NotifMgr.pendingNotifs { $0.forEach { print ($0.identifier) } }
        NotifMgr.cancelAllNotifs()
        print ("All notifs cancelled.")
        
        reqNotifAuth()
        
        locMgr.delegate = self
        locMgr.requestWhenInUseAuthorization()
    }

    func reqNotifAuth() {
        NotifMgr.instance.requestPermission { granted, error in
            print (error ?? "Notifications authorized: \(granted)")
            guard error == nil, granted else { return }
            self.registerCategory()
//            self.add10SecondNotification()
//            self.add2MinRepeatNotif()
//            self.add1MinCalRepeatNotif()
        }
    }
    
    func add2MinRepeatNotif() {
        let content = NotifMgr.createContent(title: "Done",
                                             body: "2 minutes!")
        let trigger = NotifMgr.createTrigger(with: 120,
                                             repeats: true)
        NotifMgr.addNotif(id: "2mins", content: content,
                          trigger: trigger) { error in
            print (error ?? "2 mins notif added")
        }
    }
    
    func add1MinCalRepeatNotif() {
        let content = NotifMgr.createContent(title: "1 min",
                                             body: "Times up!")
        let trigger = NotifMgr.createTrigger(with:
                                Date().addingTimeInterval(60), repeats: true)
        NotifMgr.addNotif(id: "1 min", content: content,
                          trigger: trigger) { error in
            print (error ?? "1 min timer added")
        }
    }
    
    func add10SecondNotification() {
        NotifMgr.addNotif(id: "Reminder",
                          title: "Remember!",
                          body: "Look at this!",
                          timeInterval: 10.0,
                          categoryId: CategoryName) { error in
            let timeStr = Date()
                .addingTimeInterval(10)
                .formatted(date: .omitted, time: .standard)
            print ("Notification added for \(timeStr)")
        }
    }
    
    func addLocNotification(loc : CLLocation) {
        let coord = loc.coordinate
        let content = NotifMgr.createContent(title: "Gone!",
                                             body: "You left the area.",
                                             badge: 1,
                                             categoryId: CategoryName)
        guard let trigger = NotifMgr.createTrigger(identifier: "LocBased",
                                                   lat: coord.latitude,
                                                   lng: coord.longitude,
                                                   radiusMeters: 250,
                                                   onExit: true)
            else { return }
        NotifMgr.addNotif(id: "LocNotif", content: content,
                          trigger: trigger) { error in
            print (error ?? "Location notification added.")
        }
    }
    
    func registerCategory() {
        NotifMgr.addCategory(categoryId: CategoryName,
                    actionIds: [NotifActions.edit.rawValue,
                                NotifActions.repeet.rawValue,
                                NotifActions.end.rawValue],
                    actionTitles: [NotifActions.edit.rawValue,
                                   NotifActions.repeet.rawValue,
                                   NotifActions.end.rawValue],
                    actionOptions: [.foreground, nil, .destructive],
                    actionDel: self)
    }
}

extension ViewController : NotifActionDelegate {
    func handleActionResponse(response: UNNotificationResponse) {
        guard let actionId = NotifActions(rawValue:
                                    response.actionIdentifier)
            else { return }

        switch actionId {
        case .end:
            print ("End: Done")
        case .edit:
            print ("Opening app...")
        case .repeet:
            print ("Repeat")
            if response.notification.request.trigger is
                    UNLocationNotificationTrigger {
                self.startLocation = nil
                self.locMgr.startUpdatingLocation()
            } else if response.notification.request.trigger is UNTimeIntervalNotificationTrigger {
                self.add10SecondNotification()
            }
        }
    }
}

extension ViewController : CLLocationManagerDelegate {
    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        if manager.authorizationStatus == .authorizedWhenInUse || manager.authorizationStatus == .authorizedAlways {
            manager.startUpdatingLocation()
        }
    }
    
    func locationManager(_ manager: CLLocationManager,
            didUpdateLocations locations: [CLLocation]) {

        guard let loc = locations.last else { return }

        guard let origLoc = startLocation else {
            startLocation = loc
            return
        }

        let dist = origLoc.distance(from: loc)
        print ("Traveled: \(dist)m")
        if dist > 1000 {
            manager.stopUpdatingLocation()
        }
    }
}

