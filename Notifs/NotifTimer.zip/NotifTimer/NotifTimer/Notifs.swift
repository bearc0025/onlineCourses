//
//  Notifs.swift
//  LocalNotifs
//
//  Created by Bear Cahill 2022 on 8/24/22.
//

import UserNotifications

import CoreLocation
import UIKit

protocol NotifActionDelegate {
    func handleActionResponse(response : UNNotificationResponse)
}

class NotifMgr : NSObject {
    static var instance = NotifMgr()
    private override init() {
        super.init()
        UNUserNotificationCenter.current().delegate = self
    }
    
    var foregroundPresentationOptions : UNNotificationPresentationOptions
                                        = [.banner, .sound, .badge]
    
    var actionDelegate : NotifActionDelegate?

    /// Requests notification (local and push) authorization from the user.
    ///
    /// - parameter authOptions: Types of authorization to request. UNAuthorizationOptions (e.g., .alert)
    /// - parameter completion: Closure to call with with response.

    func requestPermission(authOptions : UNAuthorizationOptions
                           = [.alert, .badge, .sound],
                completion : @escaping (Bool, Error?) -> Void) {
        
        UNUserNotificationCenter.current()
            .requestAuthorization(options: authOptions,
                                  completionHandler: completion)
    }
        
    /// Creates and returns a UNNotificationContent with the values passed in.
    static func createContent(title : String,
                       body : String,
                       sound : String? = nil,
                       badge : Int = 0,
                       categoryId : String? = nil) -> UNNotificationContent {
        
        let content = UNMutableNotificationContent()
        content.title = title
        content.body = body
        content.badge = NSNumber(value: badge)

        if let sound = sound {
            let soundName = UNNotificationSoundName(rawValue: sound)
            content.sound = UNNotificationSound(named: soundName)
        } else {
            content.sound = .default
        }

        if let categoryId = categoryId {
            content.categoryIdentifier = categoryId
        }
        
        // Can also set dictionary: [AnyHashable:Any]
        content.userInfo = ["phoneNum":"+18005551212"]
        
        return content
    }
    
    /// Creates and returns a UNNotificationTrigger with the values passed in.
    static func createTrigger(with timeInterval : TimeInterval,
                   repeats : Bool = false) -> UNNotificationTrigger {
        UNTimeIntervalNotificationTrigger(timeInterval: timeInterval,
                                          repeats: repeats)
    }
    
    /// Creates and returns a UNNotificationTrigger with the values passed in.
    static func createTrigger(with date : Date,
                              granularity : Set<Calendar.Component>
                              = [.weekday, .hour, .minute, .second],
                       repeats : Bool = false) -> UNNotificationTrigger {
        
        let dateComps = Calendar
            .current
            .dateComponents(granularity,
                            from: date)
        return UNCalendarNotificationTrigger(dateMatching: dateComps,
                                             repeats: repeats)
    }
    
    /// Creates and returns a UNNotificationTrigger with the values passed in.
    static func createTrigger(identifier : String,
                       lat : Double,
                       lng : Double,
                       radiusMeters : Double = 1000.0,
                       onEntry : Bool = true,
                       onExit : Bool = false,
                       repeats : Bool = false) -> UNNotificationTrigger? {
        
        let locMgr = CLLocationManager()
        guard locMgr.authorizationStatus == .authorizedAlways
                || locMgr.authorizationStatus == .authorizedWhenInUse else {
            print ("Region based trigger requires (at least) 'when in use' location authorization")
            return nil
        }
        
        let center = CLLocationCoordinate2D(latitude: lat,
                                            longitude: lng)
        let region = CLCircularRegion(center: center,
                                      radius: radiusMeters,
                                      identifier: identifier)
        region.notifyOnEntry = onEntry
        region.notifyOnExit = onExit
        let trigger = UNLocationNotificationTrigger(region: region,
                                                    repeats: false)
        return trigger
    }
    
    /// Creates and adds a notification to the notification center.
    static func addNotif(id : String,
                  content : UNNotificationContent,
                  trigger : UNNotificationTrigger,
                  completion : @escaping (Error?)->Void) {
        
        let req = UNNotificationRequest(identifier: id,
                                        content: content,
                                        trigger: trigger)
        UNUserNotificationCenter.current().add(req,
                        withCompletionHandler: completion)
    }
    
    /// Creates a content, trigger and notifications and adds it to the notification center.
    static func addNotif(id : String,
                  title : String,
                  body : String,
                  sound : String? = nil,
                  badge : Int = 0,
                  timeInterval : TimeInterval,
                  categoryId : String? = nil,
                  completion : @escaping (Error?)->Void) {
        let content = createContent(title: title,
                                    body: body,
                                    sound: sound,
                                    categoryId: categoryId)
        let trigger = createTrigger(with: timeInterval,
                                    repeats: false)
        addNotif(id: id, content: content,
                 trigger: trigger,
                 completion: completion)
    }

    /// Passes all pending notifications to the completion handler.
    static func pendingNotifs(completion : @escaping ([UNNotificationRequest])->Void) {
        UNUserNotificationCenter.current().getPendingNotificationRequests(completionHandler: completion)
    }
    
    /// Searches for a pending notification by identifier and passes it to the provided completion handler.
    static func findNotif(byIdentifier id : String,
                   completion : @escaping (UNNotificationRequest?)->Void) {
        pendingNotifs { notifs in
            let found = notifs.first { notif in
                notif.identifier == id
            }
            completion(found)
        }
    }
    
    static func cancelNotif(byIdentifier id : String) {
        UNUserNotificationCenter
            .current()
            .removePendingNotificationRequests(withIdentifiers: [id])
    }
    
    /// Cancels all pending notifications.
    static func cancelAllNotifs() {
        UNUserNotificationCenter
            .current()
            .removeAllPendingNotificationRequests()
    }
    
    /// Create notification actions
    ///
    /// - note: The 3 arrays passed in need to have synced values: the first id goes with the first title with the first options.
    ///
    /// - parameter actionIds: The identifiers of the actions to be included in the category.
    /// - parameter actionTitles: The titles for the actions.
    /// - parameter actionOptions: The options for the actions. Use nil if there are no options (e.g., background launch)
    static func createActions(actionIds : [String],
                              actionTitles : [String],
                              actionOptions : [UNNotificationActionOptions?])
                -> [UNNotificationAction]? {
        guard actionIds.count == actionTitles.count,
                actionIds.count == actionOptions.count else { return nil }
        
        var actions = [UNNotificationAction]()
        for index in 0..<actionIds.count {
            let action = UNNotificationAction(identifier: actionIds[index],
                                              title: actionTitles[index],
                                              options: actionOptions[index] ?? [])
            actions.append(action)
        }
        return actions
    }
    
    /// Adds a category by identifier.
    ///
    /// - note: The 3 arrays passed in need to have synced values: the first id goes with the first title with the first options.
    ///
    /// Typically the call to set the categories replaces "any previously registered categories." However, for this code I want to add categories. So this code first fetches the existing categories for this app and adds (or replaces) one of the same name.
    ///
    /// - parameter actionIds: The identifiers of the actions to be included in the category.
    /// - parameter actionTitles: The titles for the actions.
    /// - parameter actionOptions: The options for the actions. Use nil if there are no options (e.g., background launch)
    /// - parameter actionDel: The delegate to store here. When a notification launches the app, the function on the delegate will be called with the UNNotificationResponse.
    static func addCategory(categoryId : String,
                     actionIds : [String],
                     actionTitles : [String],
                     actionOptions : [UNNotificationActionOptions?],
                     actionDel : NotifActionDelegate) {
        
        NotifMgr.instance.actionDelegate = actionDel
        
        guard let actions = createActions(actionIds: actionIds,
                                          actionTitles: actionTitles,
                                          actionOptions: actionOptions)
            else { return }
        
        // notification type
        let actionCategory =
            UNNotificationCategory(identifier: categoryId,
               actions: actions,
               intentIdentifiers: [],
               hiddenPreviewsBodyPlaceholder: "%u other messages",
               options: .customDismissAction)
        
        // Register the type: get current categories first
        var allCats : Set<UNNotificationCategory> = [actionCategory]
        UNUserNotificationCenter.current().getNotificationCategories { cats in
            cats.forEach { curCat in
                if curCat.identifier != actionCategory.identifier {
                    allCats.insert(curCat)
                }
            }
            UNUserNotificationCenter
                .current()
                .setNotificationCategories(allCats)
        }
    }
    
}

extension NotifMgr : UNUserNotificationCenterDelegate {

    /// This is called when the app is in the foreground and a notification comes in.
    ///  - note: The default settings will call the completion handler with directions to have the system move forward with banner, badge and sound for the notification.
    ///
    ///  If you want something different, change the foregroundPresentationOptions value in the instance singleton.
    ///
    func userNotificationCenter(_ center: UNUserNotificationCenter,
                    willPresent notification: UNNotification,
                    withCompletionHandler completionHandler: @escaping (UNNotificationPresentationOptions) -> Void) {
        print (notification)
        completionHandler(foregroundPresentationOptions)
    }

    /// This is called when the user is opening the app, dismissing notif ("Cancel" button) or choosing notif action.
    ///
    /// - note: This code calls the handleActionResponse on the delegate (if there is one) passing in the UNNotificationResponse.
    /// The app has 30 seconds to call the completion handler passed in.
    
    func userNotificationCenter(_ center: UNUserNotificationCenter,
                                didReceive response: UNNotificationResponse,
                                withCompletionHandler completionHandler:
                                    @escaping () -> Void) {

        // The response has an action identifier that can be one of three things:
        // 1. UNNotificationDismissActionIdentifier = dismissed the notif
        //    - requires .customDismissAction in Category
        //    - see https://apple.co/3R5MEjF - have to select "Cancel" button
        // 2. UNNotificationDefaultActionIdentifier = user opened app from notif
        // 3. Custom action identifier defined in this app.
        
        print (response.actionIdentifier)

        actionDelegate?.handleActionResponse(response: response)

        // if in the background, app has 30 seconds to call this
        completionHandler()
    }
}
