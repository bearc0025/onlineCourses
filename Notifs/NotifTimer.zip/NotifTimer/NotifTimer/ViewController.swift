//
//  ViewController.swift
//  NotifTimer
//
//  Created by Bear Cahill 2022 on 8/24/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var pickerCountdown: UIDatePicker!
    @IBOutlet weak var btnStart: UIButton!
        
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        NotifMgr.instance.requestPermission { granted, error in
            print (granted)
            print (error ?? "no error")
            guard granted else { return }
            NotifMgr.addCategory(categoryId: "Repeater",
                                 actionIds: ["Repeat"],
                                 actionTitles: ["Repeat"],
                                 actionOptions: [nil],
                                 actionDel: self)
        }
    }

    @IBAction func doBtnStart(_ sender: Any) {
        UserDefaults.standard.set(pickerCountdown.countDownDuration,
                                  forKey: "TimerInterval")
        startTimer()
    }
    
    func startTimer() {
        NotifMgr.cancelAllNotifs()
        let timeInterval = UserDefaults.standard.double(forKey: "TimerInterval")
        NotifMgr.addNotif(id: "Timer", title: "Timer",
                          body: "Time's up: \(Int(timeInterval))s",
                          timeInterval: timeInterval,
                          categoryId: "Repeater") { error in
            print (error ?? "notif added")
            let time = Date()
                .addingTimeInterval(timeInterval)
                .formatted(date: .omitted, time: .standard)
            print ("Fire @ \(time)")
        }
    }
    
}

extension ViewController : NotifActionDelegate {
    func handleActionResponse(response: UNNotificationResponse) {
        let id = response.actionIdentifier
        if id == "Repeat" {
            startTimer()
        }
    }
}

