//
//  ViewController.swift
//  ServerComm
//
//  Created by Bear Cahill 2022 on 8/23/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
//        fetchString(forURL: "http://www.google.com")
//        fetchImage(forURL: "https://brainwashinc.com/images/brainwash.png")
//        fetchImageToFile(forURL: "https://brainwashinc.com/images/brainwash.png")
        
        fetchImage(forURL: "https://source.unsplash.com/random")
    }

    @IBAction func handleTap(_ sender: Any) {
        fetchImage(forURL: "https://source.unsplash.com/random")
    }
    
    func fetchString(forURL url : String) {
        guard let fetchURL = URL(string: url) else { return }
        
        URLSession.shared.dataTask(with: fetchURL)
            { data, response, error in
                guard error == nil, let d = data else { return }
                guard let str = String(data: d, encoding: .ascii) else { return }
                print (str)
            }
            .resume()
    }
    
    func fetchImage(forURL url : String) {
        guard let fetchURL = URL(string: url) else { return }
        
        URLSession.shared.dataTask(with: fetchURL)
            { data, response, error in
                guard error == nil, let d = data else { return }
                DispatchQueue.main.async {
                    let img : UIImage? = UIImage(data: d)
                    let iv = UIImageView(frame: self.view.frame)
                    iv.contentMode = .scaleAspectFit
                    iv.image = img
                    self.view.addSubview(iv)
                }
            }
            .resume()
    }
    
    func fetchImageToFile(forURL url : String) {
        guard let fetchURL = URL(string: url) else { return }
        
        // 1. downloadTask instead of dataTask
        URLSession.shared.downloadTask(with: fetchURL)
            { url, response, error in
                // 2. URL instead of Data
                guard error == nil, let urlToImage = url else { return }
                
                // 3. Load the data from the file location
                guard let d = try? Data(contentsOf: urlToImage)
                    else { return }
                
                DispatchQueue.main.async {
                    let img : UIImage? = UIImage(data: d)
                    let iv = UIImageView(frame: self.view.frame)
                    iv.contentMode = .scaleAspectFit
                    iv.image = img
                    self.view.addSubview(iv)
                }
            }
            .resume()
    }
    
    

}

