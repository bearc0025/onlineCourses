//
//  ViewController.swift
//  API
//
//  Created by Bear Cahill 2022 on 8/23/22.
//

import UIKit

struct User : Codable {
    var id : String?
    var username : String?
    var score = 0
    var active = false
}

struct Attempt : Codable {
    var id : String?
    var score = 0
    var userId : String?
}

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let someUser = User(id: "1234abc",
                            username: "Bogus",
                            score: 100,
                            active: true)
        
        postNewAttempt(user: someUser, score: 4)
        
        self.fetchAttempts()
    }

    func postNewAttempt(user : User,
                        score : Int) {

        let attempt = Attempt(score: score,
                              userId: user.id)
        guard let data = try? JSONEncoder().encode(attempt)
            else { return }
        
        guard let url = attemptsEndpoint
            else { return }
        var urlReq = URLRequest(url: url)
        
        urlReq.sendRequest(body: data) { data, error in
            // 1. check the error and unwrap the data
            guard error == nil, let d = data else { return }
            // 2. print out the response JSON as a string
            #if DEBUG
            print (String(data: d, encoding: .utf8) ?? "no value")
            #endif
            // 3. parse the JSON to an Attempt instance
            guard let newAttempt = try? JSONDecoder().decode(Attempt.self, from: d)
                else { return }
            // 4. do whatever needed with the Attempt
            print (newAttempt)
        }
        
    }

    func fetchAttempts() {
        guard let url = attemptsEndpoint else { return }
        var urlReq = URLRequest(url: url)
        
        // 1. Fetch Attempts with a GET
        urlReq.sendRequest(body: nil, method: "GET") { data, error in
            guard error == nil, let d = data else { return }
            // parse the JSON and print it out.
            guard let fetchedAttempts = try? JSONDecoder().decode([Attempt].self,
                                                                  from: d)
                else { return }
            print ("GET: \(fetchedAttempts)")
            self.updateAttempt(fetchedAttempts: fetchedAttempts)
        }
    }
    
    func updateAttempt(fetchedAttempts : [Attempt]) {
        // 2. Get the first attempt and change a value
        guard var putAttempt = fetchedAttempts.first else { return }
        putAttempt.score += 10

        // build URL with id
        guard let id = putAttempt.id else { return }
        guard let url = URL(string: APIURL + "/attempts/\(id)") else { return }
        var urlReq = URLRequest(url: url)

        // convert the Attempt to Data
        guard let dataPut = try? JSONEncoder().encode(putAttempt)
            else { return }

        // send the PUT request
        urlReq.sendRequest(body: dataPut, method: "PUT") { data, error in
            guard error == nil, let d = data else { return }
            print ("PUT: \(String(data: d, encoding: .utf8) ?? "no value")")
            self.deleteAttempt(attempt: putAttempt)
        }
    }
    
    func deleteAttempt(attempt : Attempt) {
        guard let id = attempt.id else { return }
        guard let url = URL(string: APIURL + "/attempts/\(id)") else { return }
        var urlReq = URLRequest(url: url)
        
        // 3. Send a DELETE request for the same Attempt
        urlReq.sendRequest(body: nil, method: "DELETE") { data, error in
            guard error == nil, let d = data else { return }
            print ("DELETE: \(String(data: d, encoding: .utf8) ?? "no value")")
        }

    }
    
}

