//
//  API.swift
//  API
//
//  Created by Bear Cahill 2022 on 8/23/22.
//

import Foundation

let APIURL = "https://my-json-server.typicode.com/bearc0025/api"

let usersEndpoint = URL(string: APIURL + "/users")
let attemptsEndpoint = URL(string: APIURL + "/attempts")

extension URLRequest {
    
    mutating func sendRequest(body : Data?,
                              method : String = "POST",
                    completion : @escaping (Data?, Error?)->Void) {
        // 1. application/json Content-Type header
        
        self.setValue("application/json",
                      forHTTPHeaderField: "Content-Type")
        
        
        // 2. Set the method and body
        self.httpMethod = method
        self.httpBody = body
        
        // 3. Create and start the task
        URLSession.shared.dataTask(with: self) { data, resp, error in
            // 4. Call the completion handler passed in
            completion(data, error)
        }.resume()
    }
}

