//
//  ViewController.swift
//  MovieSearch
//
//  Created by Bear Cahill 2022 on 8/23/22.
//

import UIKit

struct Search : Codable {
    var results = [Movie]()
    
    enum CodingKeys : String, CodingKey {
        case results = "Search"
    }
}

struct Movie : Codable {
    var title = ""
    var year = ""
    var poster : URL?
    
    enum CodingKeys : String, CodingKey {
        case title = "Title"
        case year = "Year"
        case poster = "Poster"
    }
}

class ViewController: UIViewController {

    @IBOutlet weak var tfSearch: UITextField!
    @IBOutlet weak var tvMovies: UITableView!
    @IBOutlet weak var ivPoster: UIImageView!
    var movies = [Movie]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        hidePoster()
        
        let movie = Movie(title: "Search for movies above.",
                          year: "", poster: nil)
        movies.append(movie)
    }

    @IBAction func handleTapOnPoster(_ sender: Any) {
        hidePoster()
    }
    
    func hidePoster() {
        animatePoster(trans: CGAffineTransform(scaleX: 0.01, y: 0.01), alpha: 0.0)
    }
    
    func displayPoster(img : UIImage?) {
        DispatchQueue.main.async {
            self.ivPoster.image = img
            self.animatePoster(trans: CGAffineTransform.identity, alpha: 1.0)
        }
    }
    
    func animatePoster(trans : CGAffineTransform, alpha : Double) {
        DispatchQueue.main.async {
            UIView.animate(withDuration: 0.3) {
                self.ivPoster.transform = trans
                self.ivPoster.alpha = alpha
            }
        }
    }
    
    func search(searchText : String) {
        movies = [Movie]()
        
        // 1. Create URL: https://www.omdbapi.com/?apikey=\(apiKey)&s=\(searchText)
        // 2. Create and resume data task with url and closure
        // 3. Closure: decode data into array of Movie items
        // 4. Closure: Update UI (e.g., reload table)
    }
    
}

extension ViewController : UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        movies.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cellMovie", for: indexPath)
        
        let movie = movies[indexPath.row]
        var config = cell.defaultContentConfiguration()
        config.text = movie.title
        config.secondaryText = movie.year
        cell.contentConfiguration = config
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let movie = movies[indexPath.row]
        
        // 1. Get the movie poster URL
        // 2. Fetch the data with the URL and closure
        // 3. Closure: Create an image from the retrieved data
        // 4. Closure: Display poster: call self.displayPoster(img:UIImage?)
    }
}

extension ViewController : UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if let searchText = textField.text {
            textField.resignFirstResponder()
            self.search(searchText: searchText)
        }
        return false
    }
}
