//
//  ViewController.swift
//  IntroToSwift
//
//  Created by Bear Cahill 2022 on 7/27/22.
//

import UIKit

class Member {
    var name = ""
    let joined = Date()
    var memberNumber = 0
    
    init(n : String, memNum : Int) {
        name = n
        memberNumber = memNum
    }
}

class Club {
    var name = ""
    var members = [Member]()
}

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        let club = Club()
        club.members.append(Member(n: "1", memNum: 1))
        club.members.append(Member(n: "2", memNum: 2))
        club.members.append(Member(n: "3", memNum: 3))
        club.members.append(Member(n: "4", memNum: 4))
        club.members.append(Member(n: "5", memNum: 5))

    }


}

