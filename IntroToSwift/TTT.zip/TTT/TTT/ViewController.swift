//
//  ViewController.swift
//  TTT
//
//  Created by Bear Cahill 2022 on 7/8/22.
//

import UIKit

enum Winner : String {
    case none
    case player1 = "Player 1", player2 = "Player 2"
}

class Game {
    var player1Turn : Bool = true
    var winner : Winner = .none
    
    var player1Moves = Array<Int>()
    var player2Moves = [Int]()
    
    var winningMoves : Dictionary<String, [Int]>
    
    init() {
        winningMoves = ["top" :     [1,2,3],
                        "middle" :  [4,5,6],
                        "bottom" :  [7,8,9],
                        "left" :    [1,4,7],
                        "center" :  [2,5,8],
                        "right" :   [3,6,9]]
        
        winningMoves["diagonal1"] = [1,5,9]
        winningMoves["diagonal2"] = [3,5,7]
    }
    
    func checkForWin() -> (winner: Winner, winningCombo: String)? {
        let moves = player1Turn ? player1Moves : player2Moves
        
        for winningCombo in winningMoves {
        }
        
        return nil
    }
    
    func addMove(move : Int) {
        if player1Turn {
            player1Moves.append(move)
        } else {
            player2Moves.insert(move, at: 0)
        }
    }
    
    func newGame() {
        winner = .none
        player1Moves.removeAll()
        player2Moves.removeAll()
    }
}

class ViewController: UIViewController {
    
    @IBOutlet var btnsMoves: [UIButton]!
    var myGame = Game()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        play()
    }
    
    func play() {
        myGame = Game()
        for btn in btnsMoves {
            btn.setTitle("", for: .normal)
            btn.isUserInteractionEnabled = true
        }
    }
    
    @IBAction func doBtnMove(_ sender: UIButton) {
        // zero-based index
        guard let index = btnsMoves.firstIndex(of: sender)
            else { return }
        let move = index + 1
        print (move)
    }
    
}

