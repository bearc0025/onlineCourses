//
//  ViewController.swift
//  HelloSwift
//
//  Created by Bear Cahill 2022 on 7/6/22.
//

import UIKit

enum NumPlayers : Int {
    case one = 1, two
}

enum Result {
    case tie
    case win(Int)
    case loss(Int)
}

enum Winner : String {
    case none
    case player1 = "Player 1", player2 = "Player 2"
}

class Game {
    var player1Turn : Bool = true
    
//    var player1Wins = false
    var winner : Winner = .none
    
    let createdAt : Date
    var finishedAt : Date?
    
    var secsSinceCreation : TimeInterval {
        createdAt.timeIntervalSince1970
    }
    
    var player1Moves = Array<Int>()
    var player2Moves = [Int]()
    
    var winningMoves : Dictionary<String, [Int]>
    
    init() {
        createdAt = Date()
        winningMoves = ["top" :     [1,2,3],
                        "middle" :  [4,5,6],
                        "bottom" :  [7,8,9],
                        "left" :    [1,4,7],
                        "center" :  [2,5,8],
                        "right" :   [3,6,9]]
        
        winningMoves["diagonal1"] = [1,5,9]
        winningMoves["diagonal2"] = [3,5,7]
        print (winningMoves["top"])
        
        print (winningMoves.keys)
        print (winningMoves.values)
    }
    
    var winnerString : String {
        switch winner {
        case .none:
            return "No winner"
        case .player1:
            return "Player 1 Wins!"
        case .player2:
            return "Player 2 Wins!"
        }
    }
    
    func checkForWin() -> (winner: Winner, winningCombo: String) {
        let moves = player1Turn ? player1Moves : player2Moves
        for winningCombo in winningMoves {
            
        }
        
        for move in player1Moves.enumerated() {
            print (move.offset)
            print (move.element)
            switch move {
            case (0, 1):
                print ("the first move is 1")
            case (0, let elem):
                print ("the first move is \(elem)")
            case (let oSet, 0..<5):
                print ("offset \(oSet) is below 5")
            case (_, 5...):
                print ("5+")
            default:
                print ("other")
            }
        }
        
        for move in player1Moves {
            switch move {
            case 0:
                print ("zero")
            case 2, 4, 6, 8:
                print ("even")
                fallthrough
            case 1...9:
                print ("non-zero")
            default:
                print ("Other")
            }
        }
        
        if let finishDate = finishedAt {
            let gameLength = finishDate.timeIntervalSince(createdAt)
            print (gameLength)
        }
        
        if let val = finishedAt?
            .timeIntervalSince1970
            .description
            .data(using: .utf8)?
            .description {
            print (val)
        }
        
        finishedAt?.addTimeInterval(500)
        
        switch player1Turn {
        case true:
            return (.player1, "top")
        case false:
            return (.player1, "center")
        }
    }
    
    func addMove(move : Int) {
        guard move > -1 else {
            print ("too low")
            return
        }
        
        if player1Turn {
            player1Moves.append(move)
        } else {
            player2Moves.insert(move, at: 0)
        }
        
        // print last move
        print (player2Moves[player2Moves.count - 1])
        
        for move in player1Moves {
            print (move)
        }
    }
    
    var correctNum = Int.random(in: 0..<10)
    
    func log(msg: String, date : Date?) {
        
        lazy var url = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        
        let data : Data? = try? Data(contentsOf: url)

        if let d = date {
            print ("\(d) \(msg)")
            print (time)
        } else {
            print (msg)
        }
        print (data)
    }
    
    func newGame(withLower lowerLimit : Int = 0, andUpper upperLimit : Int = 10) throws -> Bool {
        if lowerLimit >= upperLimit {
            throw NSError(domain: "some domain", code: 1234)
        }
        correctNum = Int.random(in: lowerLimit..<upperLimit)
        winner = .none
        player1Moves.removeAll()
        player2Moves.removeAll()
        return true
    }

    func takeTurn(guess : Int) -> Bool {
        print ("\(correctNum) \(guess)")
        if guess == correctNum {
            winner = player1Turn ? .player1 : .player2
            return true
        }
        player1Turn.toggle()
        return false
    }
}

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        play()
        
        Timer.scheduledTimer(withTimeInterval: 5,
                             repeats: false) { myTimer in
            print ("5 seconds")
        }
        
        var playerCount = NumPlayers.one
        playerCount = NumPlayers.init(rawValue: 2) ?? .one
        print (playerCount)
        
        let result = Result.win(5)
        
        if case .win(5) = result {
            print ("yes")
        }
    }
    
    func play() {
        let myGame = Game()
        var curGuess = 0
        while myGame.takeTurn(guess: curGuess) == false {
            print (curGuess)
            curGuess += 1
        }
        
        let checkResult = myGame.checkForWin()
        print (checkResult.winner)
        
        
        print ("winning number: \(curGuess)")
//        print ("Player \(myGame.player1Wins ? "1" : "2") wins!")
        
        do {
            let success = try myGame.newGame(withLower: 0,
                                             andUpper: 10)
            print(success)
        } catch {
            print (error.localizedDescription)
        }
    }
    
    
}

