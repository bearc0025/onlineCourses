//
//  ViewController.swift
//  IntroToSwift
//
//  Created by Bear Cahill 2022 on 7/27/22.
//

import UIKit

enum MemberLevel : Int {
    case guest, junior, senior, board
}

class Member {
    var name = ""
    let joined = Date()
    var memberNumber = 0
    
    init(n : String, memNum : Int) {
        name = n
        memberNumber = memNum
    }
}

class Club {
    var name = ""
    var members = [Member]()
    
    func addMember(name : String, number : Int,
                   handler : (Member)->Void) {
        let member = Member(n: name, memNum: number)
        members.append(member)
        handler(member)
    }
}

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        let club = Club()
        club.members.append(Member(n: "1", memNum: 1))
        club.members.append(Member(n: "2", memNum: 2))
        club.members.append(Member(n: "3", memNum: 3))
        club.members.append(Member(n: "4", memNum: 4))
        club.members.append(Member(n: "5", memNum: 5))
        
        club.addMember(name: "6", number: 6) { newMember in
            print (newMember.name)
        }
        
        let level = MemberLevel(rawValue: 0)
        print (level?.rawValue)     
        
    }


}

