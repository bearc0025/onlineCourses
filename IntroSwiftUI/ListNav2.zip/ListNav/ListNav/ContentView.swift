//
//  ContentView.swift
//  ListNav
//
//  Created by Bear Cahill 2022 on 9/5/22.
//

import SwiftUI

struct Movie : Identifiable {
    var id = UUID()
    
    var name = ""
    var year = ""
}

struct MovieView : View {
    var movie : Movie?
    
    var body: some View {
        HStack {
            Text(movie?.name ?? "")
            Text(movie?.year ?? "")
        }.padding()
    }
}

struct MovieDetailsView : View {
    var movie : Movie?
    
    var body: some View {
        HStack {
            Text(movie?.name ?? "")
            Text(movie?.year ?? "")
        }.padding()
    }
}

struct ContentView: View {
    
    @State private var movies = [Movie(name: "This", year: "2008"), Movie(name: "That", year: "2010")]
    
    @State private var newMovieName = ""
    @State private var newMovieYear = ""
    
    var body: some View {
        
        VStack {
            HStack {
                VStack {
                    TextField("Enter Name",
                            text: $newMovieName)
                    TextField("Enter Year",
                            text: $newMovieYear)
                }
                Button("Add") {
                    movies.append(Movie(name: newMovieName, year: newMovieYear))
                    newMovieName = ""
                    newMovieYear = ""
                }
            }
            .padding()
            NavigationView {
                List {
                    // for each movie, make a link
                    ForEach(movies) { movie in
                        NavigationLink {
                            // displayed when tapped
                            MovieDetailsView(movie: movie)
                        } label: {
                            // displayed for link
                            // (i.e., in List)
                            MovieView(movie: movie)
                        }
                    }.onDelete { indexSet in
                        self.movies.remove(atOffsets: indexSet)
                    }
                }.navigationTitle("Movies")
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
