//
//  ListNavApp.swift
//  ListNav
//
//  Created by Bear Cahill 2022 on 9/5/22.
//

import SwiftUI

@main
struct ListNavApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
