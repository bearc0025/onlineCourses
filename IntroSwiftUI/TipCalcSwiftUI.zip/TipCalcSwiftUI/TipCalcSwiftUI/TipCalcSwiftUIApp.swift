//
//  TipCalcSwiftUIApp.swift
//  TipCalcSwiftUI
//
//  Created by Bear Cahill 2022 on 9/5/22.
//

import SwiftUI

@main
struct TipCalcSwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
