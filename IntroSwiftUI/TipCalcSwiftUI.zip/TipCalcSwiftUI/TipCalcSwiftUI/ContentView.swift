//
//  ContentView.swift
//  TipCalcSwiftUI
//
//  Created by Bear Cahill 2022 on 9/5/22.
//

import SwiftUI

let numFormatter = NumberFormatter()

struct ContentView: View {
    @State private var billAmount = ""
    var billAmtDbl : Double {
        print ("billAmtDbl")
        return Double(billAmount) ?? 0.0
    }

    var tip : String {
        print ("tip")
        numFormatter.numberStyle = .currency
        return numFormatter.string(for: billAmtDbl * tipPerc) ?? ""
    }
    var total : String {
        print ("total")
        numFormatter.numberStyle = .currency
        return numFormatter.string(for: billAmtDbl + (billAmtDbl * tipPerc)) ?? ""
    }
    
    @State private var tipPerc = 0.15
    
    private var tipPercs = [0.1, 0.15, 0.2, 0.25]
    
    var body: some View {
        VStack {
            HStack {
                Text("Tip Calculator")
                    .font(.title)
                    .padding()
                Spacer()
            }
            
            TextField("Enter Bill Amount",
                      text: $billAmount)
                .padding()
            
            Picker("Select Tip Percentage",
                   selection: $tipPerc) {
                ForEach(tipPercs, id: \.self) { val in
                    Text("\(Int(val * 100))%")
                }
            }
                .pickerStyle(.segmented)
                .padding()
                .onChange(of: tipPerc) { newValue in
                    print (tipPerc)
                }
            
            VStack {
                HStack {
                    Text(tip)
                        .font(.title)
                    Text(" tip")
                    Spacer()
                }
                HStack {
                    Text(total)
                        .font(.title)
                    Text(" total")
                    Spacer()
                }
            }
            .padding()
            
            Spacer()
            
        }
        .padding()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
