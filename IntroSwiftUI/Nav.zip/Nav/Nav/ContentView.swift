//
//  ContentView.swift
//  Nav
//
//  Created by Bear Cahill 2022 on 9/5/22.
//

import SwiftUI

struct LoginView : View, Identifiable {
    var id = UUID()
    
    @State private var username = ""
    @State private var password = ""
    
    var body: some View {
        VStack {
            TextField("Username",
                      text: $username)
                .padding()
            SecureField("Password",
                        text: $password)
                .padding()
            Button("Login") {
                print ("login...")
            }
        }
    }
}

struct ContentView: View {
    
    @State private var isPresented = false
    
    @State private var loginView : LoginView?
    
    var body: some View {
        VStack {
            Text("Hello, world!")
                .padding()
                .onTapGesture {
                    isPresented = true
                }
                .sheet(isPresented: $isPresented) {
                    Text("Hi")
                }
            Text("Login")
                .padding()
                .onTapGesture {
                    loginView = LoginView()
                }
                .sheet(item: $loginView) { $0 }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
//        LoginView()
    }
}
