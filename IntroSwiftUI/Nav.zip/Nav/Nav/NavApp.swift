//
//  NavApp.swift
//  Nav
//
//  Created by Bear Cahill 2022 on 9/5/22.
//

import SwiftUI

@main
struct NavApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
