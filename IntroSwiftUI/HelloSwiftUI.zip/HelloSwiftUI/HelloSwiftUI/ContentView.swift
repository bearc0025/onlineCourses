//
//  ContentView.swift
//  HelloSwiftUI
//
//  Created by Bear Cahill 2022 on 8/30/22.
//



import SwiftUI

struct ContentView: View {
    @State private var inputVal = ""
    
    func btnTapped() {
        print ("tapped")
    }
    
    var body: some View {
        HStack {
            VStack {
                TextField("Enter Value", text: $inputVal)
                .padding()
                
                Button {
                    print (inputVal)
                    inputVal = "tapped"
                    btnTapped()
                } label: {
                    Text("Tap Me")
                }
                .padding()
                .background(.gray)
                .foregroundColor(.white)
                .cornerRadius(/*@START_MENU_TOKEN@*/10.0/*@END_MENU_TOKEN@*/)
            }
        

            Text(/*@START_MENU_TOKEN@*/"Placeholder"/*@END_MENU_TOKEN@*/)
            VStack {
                Text(/*@START_MENU_TOKEN@*/"Placeholder"/*@END_MENU_TOKEN@*/)
                Text("Hello, Bear!")
                    .padding()
                Text("Second Text")
                    .padding(.bottom)
                Text(/*@START_MENU_TOKEN@*/"Placeholder"/*@END_MENU_TOKEN@*/)
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            ContentView()
        }
    }
}
