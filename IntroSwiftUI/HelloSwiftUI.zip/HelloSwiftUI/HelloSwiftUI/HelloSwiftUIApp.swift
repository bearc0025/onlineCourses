//
//  HelloSwiftUIApp.swift
//  HelloSwiftUI
//
//  Created by Bear Cahill 2022 on 8/30/22.
//

import SwiftUI

@main
struct HelloSwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}









