//
//  ContentView.swift
//  NameList
//
//  Created by Bear Cahill 2022 on 9/5/22.
//

import SwiftUI

struct ContentView: View {
    
    @State private var names = ["Bear", "Jed", "Schmeb"]
    @State private var newName = ""

    var body: some View {
        
        VStack {
            TextField("Enter Name",
                      text: $newName)

            Button("Add") {
                names.append(newName)
                newName = ""
            }

            List {
                ForEach(names,
                        id: \.self) {
                    Text($0)
                }
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
