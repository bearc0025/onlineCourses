//
//  NameListApp.swift
//  NameList
//
//  Created by Bear Cahill 2022 on 9/5/22.
//

import SwiftUI

@main
struct NameListApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
