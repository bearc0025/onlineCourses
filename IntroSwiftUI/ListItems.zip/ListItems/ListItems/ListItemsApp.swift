//
//  ListItemsApp.swift
//  ListItems
//
//  Created by Bear Cahill 2022 on 9/3/22.
//

import SwiftUI

@main
struct ListItemsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
