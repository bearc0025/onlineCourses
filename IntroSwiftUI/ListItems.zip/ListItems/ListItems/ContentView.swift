//
//  ContentView.swift
//  ListItems
//
//  Created by Bear Cahill 2022 on 9/3/22.
//

import SwiftUI

struct Song {
    var uniqueValue = UUID()
    var name : String = ""
}

struct ContentView: View {
    
    @State private var songs =
                [Song(name : "First Song"),
                 Song(name : "Second Tune"),
                 Song(name : "Third Try")]
    
    var body: some View {
        VStack {
            Button("Add") {
                songs.append(Song(name: "Added"))
            }
            List {
                ForEach(songs,
                        id: \.uniqueValue) { song in
                    Text(song.name)
                        .onTapGesture {
                            print (song.name)
                        }
                }
                .onDelete { offsets in
                    self
                    .songs
                    .remove(atOffsets: offsets)
                }
            }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
