//
//  ViewController.swift
//  HOF
//
//  Created by Bear Cahill 2022 on 8/1/22.
//

import UIKit


struct   JSON_Data
      // in Swift with
        : Codable {
    
}

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        Timer.scheduledTimer(withTimeInterval: 5.0,
                             repeats: false,
                             block: { timer in
            print ("5 seconds")
        })
        
        let strFunc : (String)->Void = printReverse(str:)
        let strFunc2 = printReverse
        
        strFunc("test")
        strFunc2("test")
        
        logWithTime(logThis: "log me",
                    logStrFunc: printReverse)
        
        ho2(str: "test", lenFunc: ho1)
        
        DispatchQueue.global().async {

            // something on the background
            
            DispatchQueue.main.async {
                 // update UI
            }
        }
        
        logWithTime(logThis: "test with closure") { paramVal in
            print (("\(Date()): \(paramVal)"))
        }
        
        
    }

    func printReverse(str : String) -> Void {
        print (str.reversed())
    }
    
    func logWithTime(logThis : String,
                     logStrFunc : (String)->Void) {
        logStrFunc("\(Date()): \(logThis)")
    }
    
    
    func add(_ v1 : Int, and v2 : Int) -> Int {
        v1 + v2
    }
    let fAdd = add
    
    func makeString(v1 : Int,
                    v2 : Double) -> String {
        "\(v1) \(v2)"
    }
    
    func ho1(str : String) -> Int {
        str.count
    }
    func ho2(str : String, lenFunc : (String)->Int) {
        let result = lenFunc(str)
        print (result)
    }
}

