//
//  ViewController.swift
//  DealingWithData
//
//  Created by Bear Cahill 2022 on 7/29/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        
        UserDefaults.standard.set(true, forKey: "VitalBoolean")
        
        UserDefaults.standard.synchronize()
        
        
        UserDefaults.standard.set("string", forKey: "SomeString")
        let s : Any? = UserDefaults.standard.object(forKey: "SomeString")
        
        let d = UserDefaults.standard.dictionaryRepresentation()
        print (d)
        
        let names = ["Mandeville", "Göteborg", "Denton"]
        UserDefaults.standard.set(names, forKey: "Strings")
        if let names2 = UserDefaults.standard.object(forKey: "Strings") as? [String] {
            print (names2)
        }
        // OR...
        if let names2 = UserDefaults.standard.stringArray(forKey: "Strings") {
            print (names2)
        }
        
        print (UserDefaults.standard.object(forKey: "VitalBoolean"))
        UserDefaults.standard.removeObject(forKey: "VitalBoolean")
        print (UserDefaults.standard.dictionaryRepresentation().keys.contains("VitalBoolean"))
        
        
        // Hands on
        let ints = [1,2,3,4,5,6]
        
        UserDefaults.standard.set(ints, forKey: "MyInts")
        
        if let ints2 : [Int] = UserDefaults.standard.object(forKey: "MyInts") as? [Int] {
            let sum = ints2.reduce(0) { $0 + $1 }
            print (sum)
        }
        
        
    }


}

