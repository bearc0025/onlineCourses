//
//  ViewController.swift
//  JSONData
//
//  Created by Bear Cahill 2022 on 7/29/22.
//

import UIKit

class Employee : Codable, CustomStringConvertible {
    var name = ""
    var startDate = Date()
    
    var description: String {
        "\(name) \(startDate)"
    }
}

class Department : Codable, CustomStringConvertible {
    var name = ""
    var emps = [Employee]()
    
    var description: String {
        "\(name) \(emps.reduce("Emps: ") { $0 + "\($1) - "})"
    }
}

struct Movie : Codable {
    var name = ""
    var date = Date()
    var posterURL : URL?
    var rating = 0
    var isSaved = false
    
    enum CodingKeys : String, CodingKey {
        case name, date
        case posterURL = "poster"
        case rating
    }
}

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        let dept = Department()
        dept.name = "My Dept"
        let emp1 = Employee()
        emp1.name = "1"
        let emp2 = Employee()
        emp2.name = "2"
        let emp3 = Employee()
        emp3.name = "3"
        dept.emps.append(contentsOf: [emp1,emp2,emp3])

        if let data = try? JSONEncoder().encode(dept) {
            let fileURL = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask).first!.appendingPathComponent("dept.json")
            try? data.write(to: fileURL)
            if let data2 = try? Data(contentsOf: fileURL) {
                let dept2 = try? JSONDecoder().decode(Department.self, from: data2)
                print (dept2 ?? "no dept")
            }
        }
        
        let fileURL = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask).first!.appendingPathComponent("movie.json")
        
        let m1 = Movie(name: "My Movie",
                       date: Date(),
                       posterURL: URL(string: "https://www.mymovie.xyz"),
                       rating: 5)
        let m2 = Movie(name: "My Movie 2: My Other Movie",
                       date: Date(),
                       posterURL: URL(string: "https://www.mymovie2.xyz"),
                       rating: 3)

        print (fileURL.path)
        
        do {
            let jsonData = try JSONEncoder().encode([m1,m2])
            try jsonData.write(to: fileURL)
            let movies = try JSONDecoder().decode([Movie].self, from: jsonData)
            print (movies)
        } catch {
            // handle error
        }
        
    }


}

