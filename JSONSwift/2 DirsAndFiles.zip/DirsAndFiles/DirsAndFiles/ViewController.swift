//
//  ViewController.swift
//  DirsAndFiles
//
//  Created by Bear Cahill 2022 on 7/29/22.
//

import UIKit

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        let docURL = FileManager.default.urls(for: .documentDirectory,
                                              in: .userDomainMask).first!
        print (docURL)
        
        let appSupportURL = FileManager.default.urls(for: .applicationSupportDirectory,
                                                     in: .userDomainMask).first!
        print (appSupportURL)
        
        let cachesURL = FileManager.default.urls(for: .cachesDirectory,
                                               in: .userDomainMask).first!
        
        
        print (cachesURL)
        
        let tmpPath = NSTemporaryDirectory()
        print (tmpPath)
        
        if let urlToImg = Bundle.main.url(forResource: "shrug", withExtension: "png") {
            print (urlToImg)
        }
        
        let fileURL = cachesURL.appendingPathComponent("someName.txt")
        let filePathString = fileURL.path
        let fileURL2 = URL(fileURLWithPath: filePathString)
        
        writeFile(str: "Write me to a file", toURL: fileURL)
        let str = readFile(fromURL: fileURL)
        print (str ?? "no value")
        
    }
    
    func readFile(fromURL : URL) -> String? {
        guard let data = try? Data(contentsOf: fromURL)
            else { return nil }
        return String(data: data, encoding: .utf8)
    }

    func writeFile(str : String, toURL : URL) {
        print (toURL.absoluteString)
        guard let data = str.data(using: .utf8)
            else { return }
        
        do {
            try data.write(to: toURL)
        } catch {
            // handle error
        }
    }
    

}

